# Chamfer Distance 3D package
from .dist_chamfer_3D import chamfer_3DDist

__all__ = ['chamfer_3DDist']
